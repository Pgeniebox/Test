const { app, BrowserWindow} = require('electron');
const { exec } = require('child_process');
require('./server');
const os = require('os');
const getIp = require('./admin/js/getIp');
let win;


function createWindow() {
   win = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      nodeIntegration: true,
      sandbox: true,     
      contentSecurityPolicy: "default-src 'self'; script-src 'self';",
      storage: {
        persistent: true,   
        maximum: false      
      }
    }
   
  });

 const serverIp = getIp();

  win.loadURL(`http://${serverIp}:3000`);
  win.on('closed', () => {
    exec('taskkill /F /IM node.exe');
  });
}

app.on('ready', () => {
createWindow();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
if (BrowserWindow.getAllWindows().length === 0) {
  createWindow();
}
});

app.on('quit', () => {
  app.exit()
});