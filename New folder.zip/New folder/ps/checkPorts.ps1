param (
    [int]$StartRange,
    [int]$EndRange
)

function Test-Port {
    param (
        [string]$ComputerName,
        [int]$Port,
        [int]$Timeout = 50
    )

    try {
        $tcpClient = New-Object System.Net.Sockets.TcpClient
        $tcpClient.BeginConnect($ComputerName, $Port, $null, $null) | Out-Null
        if ($tcpClient.Connected) {
            $tcpClient.Close()
            return $true
        } else {
            Start-Sleep -Milliseconds $Timeout
            if ($tcpClient.Connected) {
                $tcpClient.Close()
                return $true
            } else {
                $tcpClient.Close()
                return $false
            }
        }
    } catch {
        return $false
    }
}

$portFound = $false

for ($i = $StartRange; $i -le $EndRange -and -not $portFound; $i++) {
    $ipAddress = "192.168.1.$i"
    $isPortOpen = Test-Port -ComputerName $ipAddress -Port 3000

    if ($isPortOpen) {
        Write-Output "The IP address $ipAddress is hosting on port 3000."
        $portFound = $true
    }
}
