const { execSync } = require('child_process');

function getIPAddress() {
    const scriptPath = './ps/getIp.ps1'; 
    try {
        const stdout = execSync(`powershell -ExecutionPolicy Bypass -File ${scriptPath}`);
        const ip = stdout.toString().trim();
        return ip;
    } catch (error) {
        console.error(`Error: ${error.message}`);
        return null;
    }
}


module.exports = getIPAddress;
