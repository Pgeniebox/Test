$ipConfigOutput = ipconfig | Select-String -Pattern "IPv4 Address", "Subnet Mask"
$ipAddress = ($ipConfigOutput -split ": ")[1].Trim()
Write-Output $ipAddress

