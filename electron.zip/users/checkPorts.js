const { exec } = require('child_process');

function checkPorts() {
    const scriptPath = './ps/checkPorts.ps1'; // Update with the actual path
    const startRange = 2;
    const endRange = 255;

    exec(`powershell -ExecutionPolicy Bypass -File ${scriptPath} -StartRange ${startRange} -EndRange ${endRange}`, (error, stdout, stderr) => {
        if (error) {
            console.error(`Error: ${error.message}`);
            return;
        }
        if (stderr) {
            console.error(`Error: ${stderr}`);
            return;
        }
        console.log(`Result: ${stdout}`);
    });
}

module.exports = checkPorts;
