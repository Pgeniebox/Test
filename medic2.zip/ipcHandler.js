// ipcHandler.js

const { ipcMain } = require('electron');
const fs = require('fs');
const path = require('path');
const userHomeDir = require('os').homedir();
///const storageDirectory = 'C:/Nouveau dossier/'; 

const storageDirectory =  path.join(userHomeDir, 'AppData/Local/MEDIC');



if (!fs.existsSync(storageDirectory)) {
    fs.mkdirSync(storageDirectory, { recursive: true });
  }


function setupIPCHandlers() {
    ipcMain.on('writeFile', async (event, { folder, filename, content }) => {
        try {
            
            const filePath = path.join(storageDirectory, folder);
             
            fs.mkdir(filePath, { recursive: true }, (err) => {
               
                const fileFullPath = path.join(filePath, filename);
                
                
                fs.writeFile(fileFullPath, content, (err) => {
                    if (err) {
                        event.reply('writeFile-reply', { success: false, error: err.message });
                    } else {
                        event.reply('writeFile-reply', { success: true, message: 'File created successfully' });
                    }
                });
              });

        } catch (error) {
            console.error('Error in writeFile IPC handler:', error);
            event.reply('writeFile-reply', { success: false, error: error.message });
        }
    });

    ipcMain.on('readFile', async (event, root) => {
        const filePath = path.join(storageDirectory, root);
        fs.readFile(filePath, 'utf8', (err, data) => {
            if (err) {
                event.reply('readFile-reply', { success: false, error: err.message });
            } else {
                event.reply('readFile-reply', { success: true, message: data });
            }
          });
    });

    ipcMain.on('readDir', async (event, root) => {
        const filePath = path.join(storageDirectory, root);
        fs.readdir(filePath, 'utf8', (err, data) => {
            if (err) {
                event.reply('readDir-reply', { success: false, error: err.message });
            } else {
                const folderContents = data.map(file => {
                    const fullPath = path.join(filePath, file);
                    const stats = fs.lstatSync(fullPath);
                    return {
                        name: file,
                        type: stats.isDirectory() ? 'folder' : 'file'
                    };
                });
                event.reply('readDir-reply', { success: true, message: folderContents });
            }
          });
    });

    ipcMain.on('readJson', async (event, root) => {
        const filePath = path.join(storageDirectory, root);
        fs.readFile(filePath, 'utf8', (err, data) => {
            if (err) {
                event.reply('readJson-reply', { success: false, error: err.message });
            } else {
                const js = JSON.parse(data);
                event.reply('readJson-reply', { success: true, message: js });
            }
          });
    });

    ipcMain.on('searchFile', (event, { root, fileName }) => {
        try {
            const filePath = path.join(storageDirectory, root);
            const searchResults = [];
            console.log(`Searching for ${fileName} in ${filePath}`);
            function searchDirectory(dir) {
                const items = fs.readdirSync(dir);
                for (const item of items) {
                    const fullPath = path.join(dir, item);
                    const stats = fs.lstatSync(fullPath);
                    if (stats.isDirectory()) {
                        searchDirectory(fullPath);
                    } else if (stats.isFile() && item === fileName) {
                        searchResults.push(fullPath);
                    }
                }
            }

            searchDirectory(filePath);

            if (searchResults.length > 0) {
                event.reply('searchFile-reply', { success: true, files: searchResults });
            } else {
                event.reply('searchFile-reply', { success: false, error: 'File not found' });
            }
        } catch (error) {
            console.error('Error in searchFile IPC handler:', error);
            event.reply('searchFile-reply', { success: false, error: error.message });
        }
    });

    ipcMain.on('syncJson', async (event, { root, entry0, index, entry1, key, value }) => {
        const filePath = path.join(storageDirectory, root);
    
        try {
            // Function to create directory recursively
            const createDirectoryRecursive = async (filePath) => {
                const directory = path.dirname(filePath);
                await fs.promises.mkdir(directory, { recursive: true });
            };
    
            // Function to read JSON data from file
            const readJsonFromFile = async (filePath) => {
                const data = await fs.promises.readFile(filePath, 'utf8');
                return JSON.parse(data); // Parse JSON data
            };
    
            // Function to write JSON data to file
            const writeJsonToFile = async (filePath, jsonData) => {
                await fs.promises.writeFile(filePath, JSON.stringify(jsonData, null, 2), 'utf8');
            };
    
            // Check if file path exists asynchronously
            fs.access(filePath, fs.constants.F_OK, async (err) => {
                if (err) {
                    // File doesn't exist, create directory recursively
                    try {
                        await createDirectoryRecursive(filePath);
    
                        // Create initial JSON data structure
                        const jsonData = {};
                        jsonData[entry0] = [{}];
                        jsonData[entry0][0][index] = entry1;
                        jsonData[entry0][0][key] = value;
    
                        // Write initial JSON data to file
                        await writeJsonToFile(filePath, jsonData);
    
                        event.reply('syncJson-reply', { success: true, json: jsonData });
                    } catch (err) {
                        console.error('Error creating directory or writing JSON:', err);
                        event.reply('syncJson-reply', { success: false, error: err.message });
                    }
                } else {
                    // File exists, read and update JSON data
                    try {
                        const jsonData = await readJsonFromFile(filePath);
    
                        const entry = jsonData[entry0];
                        const indx = entry.find(user => user[index] === entry1);
    
                        if (indx) {
                            indx[key] = value;
                        } else {
                            console.error('Index not found');
                            event.reply('syncJson-reply', { success: false, error: 'Index not found' });
                            return;
                        }
    
                        // Write updated JSON back to file
                        await writeJsonToFile(filePath, jsonData);
    
                        event.reply('syncJson-reply', { success: true, json: jsonData });
                    } catch (err) {
                        console.error('Error updating JSON:', err);
                        event.reply('syncJson-reply', { success: false, error: err.message });
                    }
                }
            });
        } catch (err) {
            console.error('Error:', err);
            event.reply('syncJson-reply', { success: false, error: err.message });
        }
    });
        

 

   
}



module.exports = {
    setupIPCHandlers
};


/*
 ipcMain.on('syncDir', async (event, root) => {
        storageDirectory = path.join(storageDirectory, root);
        dir.push(storageDirectory);
        fs.mkdirSync(storageDirectory, { recursive: true });
    });

    ipcMain.on('syncDirBack', async (event) => {
        if(dir.length>1){
        dir.pop();
        storageDirectory = dir[dir.length-1];
        fs.mkdirSync(storageDirectory, { recursive: true });
    }
    });
    ipcMain.on('syncHome', async (event) => {
        storageDirectory = dir[0];
        dir=[storageDirectory];
        fs.mkdirSync(storageDirectory, { recursive: true });
    });
    */