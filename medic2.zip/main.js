const { app, BrowserWindow  ,ipcMain  } = require('electron');
const { exec } = require('child_process');
require('./server');
const getIPAddress = require('./admin/js/getIp');
const path = require('path');
const { setupIPCHandlers } = require('./ipcHandler');
const os = require('os');

let win;


async function createWindow() {
   win = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'), 
      nodeIntegration: true,
      sandbox: true,     
      enableHardwareAcceleration: true,
      contextIsolation: true,
      enableRemoteModule: true,
      webSecurity: true,
      backgroundThrottling: true,
      contentSecurityPolicy: "default-src 'self'; script-src 'self';",
      storage: {
        persistent: true,   
        maximum: false      
      }
    }
   
  });
///const serverIp =  getIPAddress();
 ///win.loadFile(`./public/index.html`);
 const networkInterfaces = os.networkInterfaces();
 let serverIp;

 // Iterate through network interfaces to find IPv4 address
 Object.keys(networkInterfaces).forEach((interfaceName) => {
   networkInterfaces[interfaceName].forEach((iface) => {
     // Skip over internal (non-IPv4) and non-IPv4 addresses
     if (iface.internal || iface.family !== 'IPv4') {
       return;
     }
     serverIp = iface.address;
   });
 });
win.loadURL(`http://${serverIp}:3000`);
  win.on('closed', () => {
    exec('taskkill /F /IM node.exe');
  });

  setupIPCHandlers();


// Open DevTools - Remove in production
win.webContents.openDevTools();

}

app.on('ready', () => {
createWindow();

});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
if (BrowserWindow.getAllWindows().length === 0) {
  createWindow();
}
});

app.on('quit', () => {
  app.exit()
});
