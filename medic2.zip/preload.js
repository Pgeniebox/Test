// preload.js

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
    executeFunction: (funcName, ...args) => {
        return new Promise((resolve, reject) => {
            ipcRenderer.once(`${funcName}-reply`, (event, result) => {
                resolve(result);
            });
            ipcRenderer.send(funcName, ...args);
        });
    }
});
