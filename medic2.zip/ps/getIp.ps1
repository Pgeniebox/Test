$ipConfigOutput = ipconfig | Select-String -Pattern "Adresse IPv4","IPv4 Address", "Subnet Mask"
$ipAddress = ($ipConfigOutput -split ": ")[1].Trim()
Write-Output $ipAddress

