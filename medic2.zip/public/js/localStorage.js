function openDB() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open('fs', 1);

        request.onupgradeneeded = event => {
            const db = event.target.result;
            db.createObjectStore('handles', { keyPath: 'id' });
        };

        request.onsuccess = event => resolve(event.target.result);
        request.onerror = event => reject(event.target.error);
    });
}

// Store the directory handle in IndexedDB
async function storeDirectoryHandle(handle) {
    const db = await openDB();
    const tx = db.transaction('handles', 'readwrite');
    const store = tx.objectStore('handles');
    await store.put({ id: 'directory', handle });
    await tx.complete;
    db.close();
}

// Retrieve the directory handle from IndexedDB
async function getStoredDirectoryHandle() {
    const db = await openDB();
    const tx = db.transaction('handles', 'readonly');
    const store = tx.objectStore('handles');
    const request = store.get('directory');
    const entry = await new Promise((resolve, reject) => {
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
    });
    db.close();
    return entry ? entry.handle : null;
}

async function postF() {
try {
        let directoryHandle = await getStoredDirectoryHandle();
        dir = directoryHandle;
        if (!directoryHandle) {
            directoryHandle = await window.showDirectoryPicker();
            await storeDirectoryHandle(directoryHandle);
        }
        const fileHandle = await directoryHandle.getFileHandle('sample.txt', { create: true });
        const writable = await fileHandle.createWritable();
        await writable.write('Hello, this is a sample text file.');
        await writable.close();
        alert('File created successfully!');
    } catch (error) {
        console.error('Error creating file:', error);
        alert('Failed to create file.');
    }
}

    async function getF() {
        try {
        let directoryHandle = await getStoredDirectoryHandle();
        if (!directoryHandle) {
            directoryHandle = await window.showDirectoryPicker();
            await storeDirectoryHandle(directoryHandle);
        }
        const fileHandle = await directoryHandle.getFileHandle('sample.txt');
        const file = await fileHandle.getFile();
        const content = await file.text();
console.log(content);
    } catch (error) {
        console.error('Error reading file:', error);
        alert('Failed to read file.');
    }}

    ///////////////////////////////////////

    async function pickDirectoryAndSearchFile(fileName) {
        try {
            // Open the directory picker and get the handle
            const directoryHandle = await window.showDirectoryPicker();
            console.log('Selected Directory:', directoryHandle);
    
            // Call the recursive search function
            const fileHandle = await searchFile(directoryHandle, fileName);
            
            if (fileHandle) {
                ///console.log(`File "${fileName}" found:`, fileHandle);
                
                // Read and return the file content
                const fileContent = await readFileContent(fileHandle);
                ///console.log(`File Content:`, fileContent);
                return fileContent;
            } else {
                console.log(`File "${fileName}" not found.`);
                return null;
            }
        } catch (err) {
            console.error('Error picking or searching directory:', err);
        }
    }
    
    async function searchFile(directoryHandle, fileName) {
        for await (const [name, handle] of directoryHandle.entries()) {
            if (handle.kind === 'file' && name === fileName) {
                return handle; // File found
            } else if (handle.kind === 'directory') {
                // Recursively search in subdirectories
                const result = await searchFile(handle, fileName);
                if (result) {
                    return result; // File found in a subdirectory
                }
            }
        }
        return null; // File not found in this directory
    }
    
    async function readFileContent(fileHandle) {
        const file = await fileHandle.getFile();
        const fileContent = await file.text(); // Or use file.arrayBuffer() for binary data
        return fileContent;
    }
    
    // Call the function and search for a specific file
    pickDirectoryAndSearchFile('418-42.JPG').then((content) => {
        if (content !== null) {
            console.log('File content:', content);
        } else {
            console.log('File not found or could not read content.');
        }
    });


    //////////////////////////////////////
    async function pickDirectoryAndSearchFile(fileName) {
        try {
            // Open the directory picker and get the handle
            const directoryHandle = await window.showDirectoryPicker();
            console.log('Selected Directory:', directoryHandle);
    
            // Call the recursive search function
            const fileHandle = await searchFile(directoryHandle, fileName);
            
            if (fileHandle) {
                console.log(`File "${fileName}" found:`, fileHandle);
            } else {
                console.log(`File "${fileName}" not found.`);
            }
        } catch (err) {
            console.error('Error picking or searching directory:', err);
        }
    }
    
    async function searchFile(directoryHandle, fileName) {
        for await (const [name, handle] of directoryHandle.entries()) {
            if (handle.kind === 'file' && name === fileName) {
                return handle; // File found
            } else if (handle.kind === 'directory') {
                // Recursively search in subdirectories
                const result = await searchFile(handle, fileName);
                if (result) {
                    return result; // File found in a subdirectory
                }
            }
        }
        return null; // File not found in this directory
    }
    
    // Call the function and search for a specific file
    pickDirectoryAndSearchFile('example.txt');
    