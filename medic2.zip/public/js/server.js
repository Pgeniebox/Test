/*
const response = await fetch(`/api/files/test/post/der/lagab.txt`, {
  method: 'GET'
});

const result = await response.json();
if (response.ok) {
  console.log(result)
} 

const response = await fetch('api/files/test/post/der/lagab.txt', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify([ 'lagab adel coucou' ])
});

const result = await response.json();
*/