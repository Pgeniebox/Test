async function writeFile(folder, filename, content) {
    try {
        const result = await electronAPI.executeFunction('writeFile', { folder, filename, content });
        return result;
    } catch (error) {
        console.error('Error executing writeFile:', error);
    }
}
async function readFile(root) {
    try {
        const result = await electronAPI.executeFunction('readFile', root);
        return result;
    } catch (error) {
        console.error('Error executing readFile:', error);
    }
}
async function readDir(root) {
    try {
        const result = await electronAPI.executeFunction('readDir', root);
        return result;
    } catch (error) {
        console.error('Error executing readDir:', error);
    }
}

async function readJson(root) {
    try {
        const result = await electronAPI.executeFunction('readJson', root);
        return result;
    } catch (error) {
        console.error('Error executing readJson:', error);
    }
}
async function searchFile(root,fileName) {
    try {
        const result = await electronAPI.executeFunction('searchFile', {root,fileName});
        return result;
    } catch (error) {
        console.error('Error executing searchFile:', error);
    }
}
async function syncJson(root,entry0,index,entry1,key,value) {
    try {
        const result = await electronAPI.executeFunction('syncJson', {root,entry0,index,entry1,key,value});
        return result;
    } catch (error) {
        console.error('Error executing readJson:', error);
    }
}