/* Require /tools/constructors/tabindexMenu.js  */
function lstchY(e) { 
    "use strict";
   const cy= $('.lstch.year :contains("'+ new Date().getFullYear()+'")',e);
   cy[0].id = 'cy';
    $('.lstch.year',e)[0].scrollTo(0, cy[0].offsetTop);
}



function ctbd(e){
  "use strict";
var arr= [];
$('#ctb *',e).remove();
arr['month'] = Number($('.txt.month',e)[0].id);
arr['year'] = Number($('.txt.year',e)[0].textContent);
arr['md'] = new Date(arr.year,arr.month+1,0).getUTCDate();
arr['fd'] = new Date(arr.year,arr.month,1).getUTCDay();

let date = 1;
const currentD = new Date().toLocaleDateString();
for (let i = 0; i < 6; i++) {
if(date>arr.md){break;}
const row = document.createElement('tr');
$('#ctb',e)[0].appendChild(row);
row.classList.add('access');
$(row).attr('alt', "$('input',e.closestIs)[0].value= e.target.nonce;return true;");

for (let j = 0; j < 7; j++) {

const cell = document.createElement('td');
if((i==0&&j+1<arr.fd)||date>arr.md){ 
cell.id = 'na'}else{
cell.textContent = date;
$(cell).attr('nonce', new Date(arr.year,arr.month,date).toLocaleDateString());
if(cell.nonce===currentD){cell.id='jj'}
date++;
}
row.appendChild(cell);
}}
return arr=null;
} 





///var createCustomChanger = new aquery().customChangerFactory();
/* usage
const customCh1 = createCustomChanger('.v', 'v', '.date-input', '.inputC#', [lstchY]);
customCh1.setInitListner();
*/