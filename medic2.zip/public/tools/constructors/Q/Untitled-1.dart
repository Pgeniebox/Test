
 aquery.prototype.tabout = function(e){
   /// console.log(e);
    e.stopPropagation();
    if(e.target.nonce ==='false'){return;}
 $(document).off('click', e.data.b.tabout); 
    if($(e.data.b.a,e.data.a).length>0) { $(e.data.b.a,e.data.a)[$(e.data.b.a,e.data.a).length-1].classList.toggle(e.data.b.b);
    $('[tabIndex="1"]',e.data.a)[$('[tabIndex="1"]',e.data.a).length-1].removeAttribute('sel');
    $('[tabIndex="1"]',e.data.a)[$('[tabIndex="1"]',e.data.a).length-1].tabIndex = 0; }
    if($(e.data.b.a,e.data.a).length>0) {$('[tabIndex="1"]',e.data.a)[$('[tabIndex="1"]',e.data.a).length-1].setAttribute('sel','');
         $(document).on('click',null,e.data, e.data.b.tabout);           }
         if($(e.data.b.a,e.data.a).length==0){ $(e.data.b.c,e.data.a).attr('nonce','false'); $(document).off('click','[tabIndex] , *:has(>[sel]) *',e.data.b.tabin); $(document).off('click', e.data.b.tabout); 
        }  
}