

'use strict' ;


function aquery() {
   this.map = new Map();
    this.ready = false;
}

//aquery.prototype = Object.create(Map.prototype);
aquery.prototype.constructor = aquery;

aquery.prototype.fn = function(e) {
    for (let func of this.a) {
        if (typeof func === 'function') {
            func(e);
        }
    }
};


aquery.prototype.closeTab = function(e,a){
    $(document).off('click','.entry, .is *',a.b.tabin);
    $(document).off('click',':not(.is):not(.is *)', a.b.tabout);
    e.toggleClass('is');
    e.toggleClass('v');
    if($('.v').length>0)
        $(document).on('click','.entry, .is *',a,a.b.tabin);
    $(document).on('click',':not(.is):not(.is *)',a, a.b.tabout);
}

aquery.prototype.closeCtx = function(e,a){
    $(document).off('click',':not(.is):not(.is *)', a.b.tabout);
    e.toggleClass('is');
    e.toggleClass('v');
    $('.v').last().toggleClass('is');
   
   if($('.is').hasClass('close')){$(document).on('click',':not(.is):not(.is *)', a,a.b.tabout);}
   
}                                                                                                                                                                                                                                                               



aquery.prototype.setInitListner = function(){        
    let isf = this;
    $(document).on('click','.tab > .entry',(ev)=>{ 
        ev.stopPropagation();

    $(document).off('click','.entry, .is *',isf.tabin);
    $(document).off('click',':not(.is):not(.is *)', isf.tabout);
    $('.is.close').toggleClass('is');
    $('.v.close').toggleClass('v');
    ///isf.fn($(this).closest('.tab'));
     $(document).on('click','.entry, .is *',{b:isf},isf.tabin);
      ev.target.click();
         });
}


aquery.prototype.tabin = function(e){  
    if(e.target.id=='na'||e.data.b.busy==true){return;}
    e.data.b.busy = true;
    e.stopPropagation();
    const ctx = $(this).closest('.ctx');
    var close=false;
   if(ctx.hasClass('close')){ $(document).off('click',':not(.is):not(.is *)', e.data.b.tabout);}
    if ($(this).hasClass('entry')) {
        if (!ctx.hasClass('is')) {
            if($('.is.close').length>0){$('.close.is').toggleClass('v');}
            $('.is').toggleClass('is');
            
            ///if (ctx.hasClass('tab')){ $('.v.close').toggleClass('v'); }
            
            if (ctx.children('.pop').length !== 0) {
                window.pos = ctx.children('.pop').offset();
                /*if(!window.ppp){ window.ppp = $(e.target.parentElement)[0].getBoundingClientRect();window.pos.gtop =Math.abs( ppp.bottom-window.pos.top);window.pos.gleft =Math.abs( ppp.left-window.pos.left);}*/
                ctx.toggleClass('is');
                ctx.toggleClass('v');
                ctx.children('.pop').offset({ top: window.pos.top, left: window.pos.left });
                $('*').on('scroll', e.data.b, e.data.b.popHelper);
            } else {
                ctx.toggleClass('v');
                ctx.toggleClass('is');

            }
            $('.ctx.close:has(.is)').toggleClass('v');
            window.e = {target:this,ctxActive:$('.ctx:has(.is)'),closestIs:$(this).closest('.is'),Q:e.data.b,ev:e};
            close = new window.Function('"use strict:";'+this['attributes'].alt.value)();
            window.e = null;
        }else{        
             close = ctx.hasClass('close');
        }
        if($('.is.close').length>0){    $(document).on('click',':not(.is):not(.is *)',e.data, e.data.b.tabout);        }

        if (close)
            if (ctx.hasClass('tab')) e.data.b.closeTab($(this).closest('.tab'),e.data);
            else e.data.b.closeCtx(ctx,e.data);
    } else if ($(this).parent().hasClass('access') && 'na' !== this.id) {
        window.e = {target:this,ctxActive:$('.ctx:has(.is)'),closestIs:$(this).closest('.is'),Q:e.data.b,ev:e};
        close = new window.Function('"use strict:";'+$(this).parent()[0]['attributes'].alt.value)();
        window.e = null;
        if (close)
            e.data.b.closeCtx(ctx,e.data);
    }else if($('.is.close').length>0){    $(document).on('click',':not(.is):not(.is *)',e.data, e.data.b.tabout);        }

e.data.b.busy = false;

}



 aquery.prototype.tabout = function(e){
    if(e.data.b.busy||$(this).hasClass('entry')){return}
    e.data.b.busy = true;
     e.stopPropagation();
   $(document).off('click','.entry, .is *',e.data.b.tabin);
    $(document).off('click',':not(.is):not(.is *)', e.data.b.tabout);
    $('.is.close').toggleClass('v');
    $('.is.close').toggleClass('is');
    e.data.b.busy = false;
if($('.v').length>0)
    $('.v').last().toggleClass('is');
$(document).on('click','.entry, .is *',e.data,e.data.b.tabin);
$(document).on('click',':not(.is):not(.is *)',e.data, e.data.b.tabout);
}

aquery.prototype.popHelper = (e)=>{
    if($(e.target).find('.is>.pop,.pop:has(.is)').length==0)
        {
            return  $('.is>.pop,.pop:has(.is)').length>0||$('*').off('scroll',e.data.popHelper);
        }
        const prect = $(e.target)[0].getBoundingClientRect();
        const rect = $('.is>.pop,.pop:has(.is)').closest('.ctx')[0].getBoundingClientRect();

        $('.is>.pop,.pop:has(.is)',e.target).offset({
            top: Math.min(Math.max(rect.bottom,prect.top),prect.bottom),
            left: Math.min(Math.max(rect.left,prect.left),prect.right)
          });
        
        /*$('.pop',e.target).offset({top:  $('*:has(>[is]+.pop)')[0].getBoundingClientRect().bottom,left: $('*:has(>[is]+.pop)')[0].getBoundingClientRect().left});*/
}







aquery.prototype.customChangerFactory = function() {

    return function() {
 
        return new aquery();
    };
   
};                                                                                        

var createCustomChanger = new aquery().customChangerFactory();
const Q = createCustomChanger();




/*USAGE:
var createCustomChanger = new aquery().customChangerFactory();
const customCh1 = createCustomChanger('.v', 'v', '.date-input', '.inputC#', [lstchY, ctbd]);
customCh1.setInitListner();
*/



