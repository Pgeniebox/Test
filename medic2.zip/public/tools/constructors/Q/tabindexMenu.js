/*Created by lagab adel*/
/*Help:
aquery.a: class to toggle '.v'
aquery.b: the same class but without . 'v'
aquery.c: first tabIndex0 entry
aquery.d: class of the parent of aquery.c, to get its parent that you will toggle its class
aquery.e: list of functions to run whene the first click in aquery.c 
///////////
-- add tabIndex 0 to an element that you want to click, it will toggle its parent class (aquery.a)
-- whene you add accessKey attr to parent of clickable elements, this clickable elements will execute the fnuctions that are in the accessKey
-- in the functions of accessKey, you can use (e), it contain all the event details
-- you can use aquery.closeTab(e); in your accessKey functions if you want to close the current tabindex1
, example of usage for specefic element:  
<div class="parent" accessKey="eval(e.target.nonce);"><div nonce="customAquery.closeTab(e);"></div>
example of usage for all the elements:
 <div class="parent" accessKey="customAquery.closeTab(e);">........</div>
--to use another window you should  set an id for the parent of (aquery.c) wich is (aquery.d)
--use id "na" to element child of .access parent to ignore it
--use return true , in the accessKey function to close the tab
-- use e.data.b.closeAllTabs(e.data.b) to close all the tabs
-- use e.data.a in function to specify the context, e.data.a = parent of aquery.c
-- e.data.c = aquery.c
-- e.data.c = aquery
-- e.data.a = aquery.d + id (parent of aquery.c)
*/

///'use strict' ;



function aquery(a, b, c, d, e,f) {
    this.ready = false;
    this.close = f||false;
    this.a = a;
    this.b = b;
    this.c = c;
    this.d = d;
    this.e = e;
}

// Method to run all functions in functionsList with a given context
aquery.prototype.fn = function(a) {
    for (let func of this.e) {
        if (typeof func === 'function') {
            func(a);
        }
    }
};


aquery.prototype.closeAllTabs = function(e){
    window.$(document).off('click','[tabIndex] , *:has(>[sel]) *',e.tabin);
    window.$(document).off('click','*:not(*:has(>[sel]) *)', e.tabout);
            $('[tabIndex="1"]').attr('tabindex','0');
            $('[nonce="true"]').attr('nonce','false');
            $('[sel]').removeAttr('sel');
          $(e.a).toggleClass(e.b);
}

aquery.prototype.closeTab = function(e){
    
    window.$(window.$('*:has(>[sel]) [sel]'))[0].tabIndex =0;
    window.$(window.$('*:has(>[sel]) [sel]')).removeAttr('sel');
    window.$(e.data.b.a,e.data.a)[window.$(e.data.b.a,e.data.a).length-1].classList.toggle(e.data.b.b);
        window.$('[tabIndex="1"]',e.data.a)[window.$('[tabIndex="1"]',e.data.a).length-1].setAttribute('sel','');
       
}                                                                                                                                                                                                                                                               


aquery.prototype.setInitListner = function(){        
    let self = this;
    $(document).on('click','*:has(>'+self.c+')',(ev)=>{ 
         if(!ev.target.classList.contains(self.c.replace('.',''))){return;}
        ev.stopPropagation();

        if(undefined== ev.target.nonce||ev.target.nonce.length==0){return;}
    $(document).off('click','[tabIndex] , *:has(>[sel]) *',self.tabin);
    $(document).off('click', self.tabout);
            $('[tabIndex="1"]').attr('tabindex','0');
            $('[nonce="true"]').attr('nonce','false');
            $('[sel]').removeAttr('sel');
          $(self.a).toggleClass(self.b);
    $(ev.target).attr('nonce','true');
    self.fn($(self.d+ev.target.parentElement.id));
    
     $(document).on('click','[tabIndex] , *:has(>[sel]) *',{a:$(self.d+ev.target.parentElement.id).parent(),b:self},self.tabin);
      ev.target.click();
         });
}


aquery.prototype.tabin = function(e){
    e.data.b.busy = true;
    e.stopPropagation();  
    if(e.target.nonce ==='false'){return;}
    window.$(document).off('click','[tabIndex] , *:has(>[sel]) *',e.data.b.tabin);
    if(e.target.tabIndex==0&&e.target.classList.contains('entry')){
    if(window.$(e.data.b.a,e.data.a).length>0) {window.$('[tabIndex="1"]',e.data.a)[window.$('[tabIndex="1"]',e.data.a).length-1].removeAttribute('sel'); 
    window.$(document).off('click','*:not(*:has(>[sel]) *)', e.data.b.tabout)}
    e.target.tabIndex =1;
    window.$('[tabIndex="1"]',e.data.a)[window.$('[tabIndex="1"]',e.data.a).length-1].setAttribute('sel','');
    if($(e.target).next().hasClass('pop')){
        $(e.target,e.data.a).next()[0].style.position = 'fixed';
        const pos = window.$(e.target,e.data.a)[0].getBoundingClientRect().bottom;
        console.log(pos)
        window.$(e.target,e.data.a).next().offset({top:321});
        }

    e.target.parentElement.classList.toggle(e.data.b.b); 
    window.$(document).on('click','*:not(*:has(>[sel]) *)',e.data, e.data.b.tabout);}
    else if(e.target.tabIndex==1) {
    e.target.parentElement.classList.toggle(e.data.b.b);
     window.$(document).off('click','*:not(*:has(>[sel]) *)', e.data.b.tabout);
        window.$('[tabIndex="1"]',e.data.a)[window.$('[tabIndex="1"]',e.data.a).length-1].removeAttribute('sel');
        e.target.tabIndex =0;
        if(window.$(e.data.b.a,e.data.a).length>0) {   window.$('[tabIndex="1"]',e.data.a)[window.$('[tabIndex="1"]',e.data.a).length-1].setAttribute('sel','');
              window.$(document).on('click','*:not(*:has(>[sel]) *)',e.data, e.data.b.tabout);           }
    }else if(e.target.parentElement.classList.contains('access')&&"na"!==e.target.id){
        window.e=e;
              const g =  new window.Function(e.target.parentElement.accessKey)();
                 window.e = null;
                 if(g){e.data.b.closeTab(e)}
     }
    if(window.$(e.data.b.a,e.data.a).length>0){ window.$(document).on('click','[tabIndex] , *:has(>[sel]) *',e.data,e.data.b.tabin);}
e.data.b.busy = false;
}



 aquery.prototype.tabout = function(e){
    if(e.data.b.busy){return}
    e.stopPropagation();
    if(window.$(e.data.b.a).length===1&&!e.data.b.close){ return; }
    if(e.target.nonce ==='false'){return;}
    window.$(document).off('click','[tabIndex] , *:has(>[sel]) *',e.data.b.tabin);
    window.$(document).off('click','*:not(*:has(>[sel]) *)', e.data.b.tabout);
    window.$(window.$('*:has(>[sel]) > [sel]'))[0].tabIndex =0;
    window.$(window.$('*:has(>[sel]) > [sel]')).removeAttr('sel');
    window.$(e.data.b.a,e.data.a)[window.$(e.data.b.a,e.data.a).length-1].classList.toggle(e.data.b.b);
    if(window.$('[tabIndex="1"]',e.data.a).is('*')){
        window.$('[tabIndex="1"]',e.data.a)[window.$('[tabIndex="1"]',e.data.a).length-1].setAttribute('sel','');
        window.$(document).on('click','[tabIndex] , *:has(>[sel]) *',e.data,e.data.b.tabin);
    window.$(document).on('click','*:not(*:has(>[sel]) *)', e.data,e.data.b.tabout);
    return;
    }
        window.$(e.data.b.c,e.data.a).attr('nonce','false');
}

aquery.prototype.modify = function(a, b, c, d, e){

    this.a = a||this.a;
    this.b = b||this.b;
    this.c = c||this.c;
    this.d = d||this.d
    this.e = e||this.e;
}

aquery.prototype.customChangerFactory = function() {
    return function(a, b, c, d, e) {
        return new aquery(a, b, c, d, e);
    };
   
};                                                                                        






/*USAGE:
var createCustomChanger = new aquery().customChangerFactory();
const customCh1 = createCustomChanger('.v', 'v', '.date-input', '.inputC#', [lstchY, ctbd]);
customCh1.setInitListner();
*/


