class DirManager {
    constructor() {
      this.directoryHandle = null;
      this.permissionGranted = false;
      this.history = [];
    }
  
    async init() {
      try {
        this.directoryHandle = await this.getStoredDirectoryHandle();
        if (!this.directoryHandle) {
          this.directoryHandle = await window.electronAPI.showDirectoryPicker();
          await this.storeDirectoryHandle(this.directoryHandle);
        }
        this.permissionGranted = true; // Assuming permission is always granted in Electron setup
      } catch (err) {
        console.error('Error initializing directory:', err);
      }
    }
  
    async requestPermission(handle) {
      // Function to request permission, not fully implemented in Electron setup
      return true; // Mocking permission granted in Electron context
    }
  
    async getDir(directoryName) {
      if (!this.directoryHandle) await this.init();
      const targetDirectoryHandle = await this.searchDirectory(this.directoryHandle, directoryName);
      if (targetDirectoryHandle) {
        return await this.showDirectoryContent(targetDirectoryHandle);
      } else {
        console.log(`Directory "${directoryName}" not found.`);
        return null;
      }
    }
  
    async getAllDirs(directoryName) {
      if (!this.directoryHandle) await this.init();
      const results = {};
      await this.searchAllDirectories(this.directoryHandle, directoryName, results);
      return results;
    }
  
    async selectDir(directoryName) {
      if (!this.directoryHandle) await this.init();
      const targetDirectoryHandle = await this.searchDirectory(this.directoryHandle, directoryName);
      if (targetDirectoryHandle) {
        this.history.push(this.directoryHandle); // Save current directory to history
        this.directoryHandle = targetDirectoryHandle;
      } else {
        console.log(`Directory "${directoryName}" not found.`);
      }
    }
  
    goBack() {
      if (this.history.length > 0) {
        this.directoryHandle = this.history.pop();
      } else {
        console.log('No previous directory to go back to.');
      }
    }
  
    async getFile(fileName) {
      if (!this.directoryHandle) await this.init();
      const fileHandle = await this.searchFile(this.directoryHandle, fileName);
      if (fileHandle) {
        const fileContent = await window.electronAPI.readFile(fileHandle.path);
        return { path: fileHandle.path, content: fileContent };
      } else {
        console.log(`File "${fileName}" not found.`);
        return null;
      }
    }
  
    async getAllFiles(fileName) {
      if (!this.directoryHandle) await this.init();
      const results = {};
      await this.searchAllFiles(this.directoryHandle, fileName, results);
      return results;
    }
  
    async showFolders() {
      if (!this.directoryHandle) await this.init();
      const folders = {};
      const entries = await window.electronAPI.readDirectory(this.directoryHandle);
      for (const entry of entries) {
        if (entry.kind === 'directory') {
          folders[entry.name] = entry.kind;
        }
      }
      return folders;
    }
  
    async showFiles() {
      if (!this.directoryHandle) await this.init();
      const files = {};
      const entries = await window.electronAPI.readDirectory(this.directoryHandle);
      for (const entry of entries) {
        if (entry.kind === 'file') {
          files[entry.name] = entry.kind;
        }
      }
      return files;
    }
  
    async showBoth() {
      if (!this.directoryHandle) await this.init();
      const contents = {};
      const entries = await window.electronAPI.readDirectory(this.directoryHandle);
      for (const entry of entries) {
        contents[entry.name] = entry.kind;
      }
      return contents;
    }
  
    async searchDirectory(directoryPath, directoryName) {
      const entries = await window.electronAPI.readDirectory(directoryPath);
      for (const entry of entries) {
        if (entry.kind === 'directory' && entry.name === directoryName) {
          return path.join(directoryPath, entry.name);
        } else if (entry.kind === 'directory') {
          const result = await this.searchDirectory(path.join(directoryPath, entry.name), directoryName);
          if (result) {
            return result;
          }
        }
      }
      return null;
    }
  
    async searchAllDirectories(directoryPath, directoryName, results) {
      const entries = await window.electronAPI.readDirectory(directoryPath);
      for (const entry of entries) {
        if (entry.kind === 'directory' && entry.name === directoryName) {
          results[entry.name] = await this.showDirectoryContent(path.join(directoryPath, entry.name));
        } else if (entry.kind === 'directory') {
          await this.searchAllDirectories(path.join(directoryPath, entry.name), directoryName, results);
        }
      }
    }
  
    async showDirectoryContent(directoryPath) {
      const contents = {};
      const entries = await window.electronAPI.readDirectory(directoryPath);
      for (const entry of entries) {
        contents[entry.name] = entry.kind;
      }
      return contents;
    }
  
    async searchFile(directoryPath, fileName) {
      const entries = await window.electronAPI.readDirectory(directoryPath);
      for (const entry of entries) {
        if (entry.kind === 'file' && entry.name === fileName) {
          return { path: path.join(directoryPath, entry.name), name: entry.name };
        } else if (entry.kind === 'directory') {
          const result = await this.searchFile(path.join(directoryPath, entry.name), fileName);
          if (result) {
            return result;
          }
        }
      }
      return null;
    }
  
    async searchAllFiles(directoryPath, fileName, results) {
      const entries = await window.electronAPI.readDirectory(directoryPath);
      for (const entry of entries) {
        if (entry.kind === 'file' && entry.name === fileName) {
          const fileContent = await window.electronAPI.readFile(path.join(directoryPath, entry.name));
          results[path.join(directoryPath, entry.name)] = fileContent;
        } else if (entry.kind === 'directory') {
          await this.searchAllFiles(path.join(directoryPath, entry.name), fileName, results);
        }
      }
    }
  
    openDB() {
      return new Promise((resolve, reject) => {
        const request = window.indexedDB.open('fss', 1);
  
        request.onupgradeneeded = event => {
          const db = event.target.result;
          db.createObjectStore('handles', { keyPath: 'id' });
        };
  
        request.onsuccess = event => resolve(event.target.result);
        request.onerror = event => reject(event.target.error);
      });
    }
  
    async storeDirectoryHandle(handle) {
      const db = await this.openDB();
      const tx = db.transaction('handles', 'readwrite');
      const store = tx.objectStore('handles');
      await store.put({ id: 'directory', handle });
      await tx.complete;
      db.close();
    }
  
    async getStoredDirectoryHandle() {
      const db = await this.openDB();
      const tx = db.transaction('handles', 'readonly');
      const store = tx.objectStore('handles');
      const request = store.get('directory');
      const entry = await new Promise((resolve, reject) => {
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
      });
      db.close();
      return entry ? entry.handle : null;
    }
  }
  

/*class DirManager {
    constructor() {
        this.directoryHandle = null;
        this.permissionGranted = false;
        this.history = [];
    }

    async init() {
        try {
            this.directoryHandle = await this.getStoredDirectoryHandle();
            if (!this.directoryHandle) {
                this.directoryHandle = await window.electronAPI.showDirectoryPicker();
                await this.storeDirectoryHandle(this.directoryHandle);
            }
            this.permissionGranted = await this.directoryHandle.queryPermission();
            console.log(this.permissionGranted);
            if(this.permissionGranted==="prompt"){  this.permissionGranted = await this.directoryHandle.requestPermission({mode: 'readwrite'});
        if(this.permissionGranted!=="prompt"){   this.directoryHandle = await window.selectronAPI.showDirectoryPicker();  await this.storeDirectoryHandle(this.directoryHandle);             }
        
        } 
        } catch (err) {
            this.directoryHandle = await window.electronAPI.showDirectoryPicker();   await this.storeDirectoryHandle(this.directoryHandle);  
            console.error('Error picking directory:', err);
        }
    }

    async requestPermission(handle) {
        if (this.permissionGranted) return true;
        const opts = { mode: 'readwrite' };
        if (await handle.requestPermission(opts) === 'granted') {
            this.permissionGranted = true;
            return true;
        }
        return false;
    }

    async getDir(directoryName) {
        if (!this.directoryHandle) await this.init();
        const targetDirectoryHandle = await this.searchDirectory(this.directoryHandle, directoryName);
        if (targetDirectoryHandle) {
            return await this.showDirectoryContent(targetDirectoryHandle);
        } else {
            console.log(`Directory "${directoryName}" not found.`);
            return null;
        }
    }

    async getAllDirs(directoryName) {
        if (!this.directoryHandle) await this.init();
        const results = {};
        await this.searchAllDirectories(this.directoryHandle, directoryName, results);
        return results;
    }

    async selectDir(directoryName) {
        if (!this.directoryHandle) await this.init();
        const targetDirectoryHandle = await this.searchDirectory(this.directoryHandle, directoryName);
        if (targetDirectoryHandle) {
            this.history.push(this.directoryHandle); // Save current directory to history
            this.directoryHandle = targetDirectoryHandle;
        } else {
            console.log(`Directory "${directoryName}" not found.`);
        }
    }

    goBack() {
        if (this.history.length > 0) {
            this.directoryHandle = this.history.pop();
        } else {
            console.log('No previous directory to go back to.');
        }
    }

    async getFile(fileName) {
        if (!this.directoryHandle) await this.init();
        const fileHandle = await this.searchFile(this.directoryHandle, fileName);
        if (fileHandle) {
            const fileContent = await this.readFileContent(fileHandle);
            return { path: fileHandle.name, content: fileContent };
        } else {
            console.log(`File "${fileName}" not found.`);
            return null;
        }
    }

    async getAllFiles(fileName) {
        if (!this.directoryHandle) await this.init();
        const results = {};
        await this.searchAllFiles(this.directoryHandle, fileName, results);
        return results;
    }

    async showFolders() {
        if (!this.directoryHandle) await this.init();
        const folders = {};
        for await (const [name, handle] of this.directoryHandle.entries()) {
            if (handle.kind === 'directory') {
                folders[name] = handle.kind;
            }
        }
        return folders;
    }

    async showFiles() {
        if (!this.directoryHandle) await this.init();
        const files = {};
        for await (const [name, handle] of this.directoryHandle.entries()) {
            if (handle.kind === 'file') {
                files[name] = handle.kind;
            }
        }
        return files;
    }

    async showBoth() {
        if (!this.directoryHandle) await this.init();
        const contents = {};
        for await (const [name, handle] of this.directoryHandle.entries()) {
            contents[name] = handle.kind;
        }
        return contents;
    }

    async searchDirectory(directoryHandle, directoryName) {
        for await (const [name, handle] of directoryHandle.entries()) {
            if (handle.kind === 'directory' && name === directoryName) {
                return handle; // Directory found
            } else if (handle.kind === 'directory') {
                const result = await this.searchDirectory(handle, directoryName);
                if (result) {
                    return result; // Directory found in a subdirectory
                }
            }
        }
        return null; // Directory not found
    }

    async searchAllDirectories(directoryHandle, directoryName, results) {
        for await (const [name, handle] of directoryHandle.entries()) {
            if (handle.kind === 'directory' && name === directoryName) {
                results[name] = await this.showDirectoryContent(handle); 
            } else if (handle.kind === 'directory') {
                await this.searchAllDirectories(handle, directoryName, results);
            }
        }
    }

    async showDirectoryContent(directoryHandle) {
        const contents = {};
        for await (const [name, handle] of directoryHandle.entries()) {
            contents[name] = handle.kind;
        }
        return contents;
    }

    async searchFile(directoryHandle, fileName) {
        for await (const [name, handle] of directoryHandle.entries()) {
            if (handle.kind === 'file' && name === fileName) {
                return handle; // File found
            } else if (handle.kind === 'directory') {
                const result = await this.searchFile(handle, fileName);
                if (result) {
                    return result; // File found in a subdirectory
                }
            }
        }
        return null; // File not found
    }

    async searchAllFiles(directoryHandle, fileName, results) {
        for await (const [name, handle] of directoryHandle.entries()) {
            if (handle.kind === 'file' && name === fileName) {
                const fileContent = await this.readFileContent(handle);
                results[handle.name] = fileContent; // File found
            } else if (handle.kind === 'directory') {
                await this.searchAllFiles(handle, fileName, results);
            }
        }
    }

    async readFileContent(fileHandle) {
        const file = await fileHandle.getFile();
        return await file.text(); // Or use file.arrayBuffer() for binary data
    }

    openDB() {
        return new Promise((resolve, reject) => {
            

            const request = window.indexedDB.open('fss', 1);

            request.onupgradeneeded = event => {
                const db = event.target.result;
                db.createObjectStore('handles', { keyPath: 'id' });
            };

            request.onsuccess = event => resolve(event.target.result);
            request.onerror = event => reject(event.target.error);
        });
    }

    async storeDirectoryHandle(handle) {
        const db = await this.openDB();
        const tx = db.transaction('handles', 'readwrite');
        const store = tx.objectStore('handles');
        await store.put({ id: 'directory', handle });
        await tx.complete;
        db.close();
    }

    async getStoredDirectoryHandle() {
        const db = await this.openDB();
        const tx = db.transaction('handles', 'readonly');
        const store = tx.objectStore('handles');
        const request = store.get('directory');
        const entry = await new Promise((resolve, reject) => {
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
        db.close();
        return entry ? entry.handle : null;
    }
}

*/
// Usage example:
/*

// Usage example:
(async () => {
    const dir = new DirManager();
    await dir.init(); // Initialize and get permission

    // Get directory content
    const dirContent = await dir.getDir('folderA');
    console.log('Directory Content:', dirContent);

    // Get all directories with the name 'folderA'
    const allDirs = await dir.getAllDirs('folderA');
    console.log('All Directories:', allDirs);

    // Select a directory
    await dir.selectDir('folderA');
    console.log('Current Directory:', dir.directoryHandle);

    // Go back to the previous directory
    dir.goBack();
    console.log('After going back, Current Directory:', dir.directoryHandle);

    // Show only folders in the current directory
    const folders = await dir.showFolders();
    console.log('Folders in Current Directory:', folders);

    // Show only files in the current directory
    const files = await dir.showFiles();
    console.log('Files in Current Directory:', files);

    // Show both files and folders in the current directory
    const both = await dir.showBoth();
    console.log('Files and Folders in Current Directory:', both);

    // Get file content
    const fileContent = await dir.getFile('fileA.txt');
    console.log('File Content:', fileContent);

    // Get all files with the name 'fileA.txt'
    const allFiles = await dir.getAllFiles('fileA.txt');
    console.log('All Files:', allFiles);
})();
*/