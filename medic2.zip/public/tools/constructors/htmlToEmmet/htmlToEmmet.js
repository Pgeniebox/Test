///////Created by lagab adel



function abbreviate(htmlString, selector,b) {
/*
if b = true; so the selector is included;
*/


    var doc = new DOMParser().parseFromString(htmlString, 'text/html');
    var root = doc.documentElement.querySelector(selector);
    let start = 1;
    if(!b){start=0;}
    function generateAbbreviation(node) {
        
        if (!node) return '';
        let abbreviation='';

        if(start==1){    
             abbreviation = node.localName;
        for (let i = 0; i < node.attributes.length; i++) {
            const attr = node.attributes[i];
            if (attr.name === 'class') {
                abbreviation += '.' + Array.from(node.classList).join('.');
                continue;
            }
            if (attr.name === 'id') {
                abbreviation += '#' + attr.value;
                continue;
            }
            abbreviation += `[${attr.name}="${attr.value}"]`;
        }

        if (node.childNodes.length > 0) {
            for (let child of node.childNodes) {
                if (child.nodeType === Node.TEXT_NODE && child.nodeValue.trim().length > 0) {
                    abbreviation += `{${child.nodeValue.trim()}}`;
                }
            }
        }
        }

        if (node.children.length > 0) {
            start=1; 
            let childAbbreviations = '';
            let count = 1;
            for (let i = 0; i < node.children.length; i++) {
                if (i > 0 && node.children[i].outerHTML === node.children[i - 1].outerHTML) {
                    count++;
                } else {
                    if (count > 1) {
                        childAbbreviations += '*' + String(count);
                        count = 1;
                    }
                    if (i > 0) {
                        childAbbreviations += '+';
                    }
                    childAbbreviations += generateAbbreviation(node.children[i]);
                }
            }
            if (count > 1) {
                childAbbreviations += '*' + String(count);
            }
            abbreviation += '>' + childAbbreviations;
        }

        return abbreviation;
    }

    return generateAbbreviation(root);
}

// Example usage
/*
const ulHtml = document.querySelector('.autoC').outerHTML;
const abbreviation = abbreviate(ulHtml, '.autoC',true);
console.log(abbreviation);
*/