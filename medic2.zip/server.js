const express = require('express');
const path = require('path');
const http = require('http');
const fs = require('fs');
const app = express();

app.use(express.static(path.join(__dirname, 'public/')));

app.use(express.json()); 

const storageDirectory = 'C:/database/'; 

// Ensure the storage directory exists
if (!fs.existsSync(storageDirectory)) {
  fs.mkdirSync(storageDirectory, { recursive: true });
}

app.post('/api/files/*/:filename', (req, res) => {
  const filePath = path.join(storageDirectory, req.params[0]);
  const filename = req.params.filename;
  
  const content = req.body[0]; 

  if (!content) {
    return res.status(400).json({ error: 'filename and content are required' ,filePath,content,filename});
  }

  fs.mkdir(filePath, { recursive: true }, (err) => {
    if (err) {
      return res.status(500).json({ error: 'Failed to create folder', err });
    }
    
    const root = path.join(filePath, filename);
      
    fs.writeFile(root, content, (err) => {
      if (err) {
        return res.status(500).json({ error: 'Failed to create file', err });
      }
      res.status(201).json({ message: 'File created successfully' });
    });
  });
});


app.get('/api/files/*/:filename', (req, res) => {
  const folder = req.params[0];
  const filename = req.params.filename;
  const filePath = path.join(storageDirectory, folder, filename);
  

  fs.readFile(filePath, 'utf8', (err, data) => {
    if (err) {
      return res.status(404).json({ error: 'File not found', filePath });
    }
    res.status(200).json({ content: data });
  });
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/index.html'));
});

const PORT = 3000;

const server = http.createServer(app);

server.listen(PORT,'0.0.0.0' ,() => {
  console.log(`Server running at http://localhost:${PORT}/`);
});













