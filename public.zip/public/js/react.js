let ar = [];
ar['s'] = [];
ar['sa'] = [];
ar['sel']=(e)=>{    ar.s.push(e);       }
ar['selAll']=(ee)=>{    ee.forEach(e => {
    ar.sa.push(e);  
});                 }

